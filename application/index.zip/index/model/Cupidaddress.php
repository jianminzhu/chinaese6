<?php

namespace app\index\model;

use think\Model;

class cupidaddress extends Model
{
    //
}
