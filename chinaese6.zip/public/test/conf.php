<?php
return array(
    'host' => 'az1-ls7.a2hosting.com',
    'user' => 'chinese6_zjm',
    'password' => 'jzm2019ok',
    'dbName' => 'chinese6_companion',
    'charSet' => 'utf8',
    'port' => '3306'
);