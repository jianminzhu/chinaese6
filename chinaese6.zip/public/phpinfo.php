<?php 
	
	echo phpinfo();
	