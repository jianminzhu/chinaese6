<?php



echo phpinfo();


?>