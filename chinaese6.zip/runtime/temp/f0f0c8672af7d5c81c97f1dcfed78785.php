<?php /*a:3:{s:95:"C:\Users\learn\Desktop\servers\nginx-1.15.8\chinaese6\application\index\view\index\profile.html";i:1551163583;s:47:"../application/index/view/index/_commoncss.html";i:1551352303;s:42:"../application/index/view/index/_head.html";i:1551339764;}*/ ?>
<!DOCTYPE html>
<html dir="ltr" lang="zh-Hans" data-device="desktop">
<head>


    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">


    <title>Elva / 35 / 女性 / 太原市, 山西, 中国 | ChinaLoveCupid.com</title>


    <meta id="defaultmessage" content="处理过程中发生问题"/>

    <meta name="viewport"
          content="height=device-height, initial-scale=1, user-scalable=no, maximum-scale=1, shrink-to-fit=yes">


    <meta name="stm-result" content="ok"/>


    <link rel="shortcut icon" href="/favicon.ico"/>
<link rel="stylesheet" href="/assets/desktop/css/chinalovecupid-base.css?v=22">
<link href="/gcss/css1.css" rel="stylesheet">
<link href="/gcss/css2.css" rel="stylesheet">
<link href="/gcss/css3.css" rel="stylesheet">
<link href="/gcss/notosanstc.css" rel="stylesheet"/>
<link href="/gcss/notosansscsliced.css" rel="stylesheet"/>
<link href="/gcss/css_M+PLUS+1p.css" rel="stylesheet">
<link href="/gcss/css_Tajawal.css" rel="stylesheet">
<script src="/js/jquery-3.3.1.min.js"></script>
<script src="/js/tolang.js"></script>

</head>
<body>
<div class="header flex items-center justify-between">
    <div class="col-6 header-nav-min-width header-nav-max-width z0 mx2">
        <div class="flex items-center justify-between p0 m0 h3">
            <a href="/" class="flex" title="xxxx">
                <div class="z2 center col-12">www.chinalove1.com</div>
            </a>
            <a href="/" class="count" ><?php echo lang('首页'); ?></a>

            <a href="/index.php/index/mail/msglist" class="count" <?php if(app('session')->get('isLogin') == true): ?>data-badge="<?php echo htmlentities((isset($msg['count']) && ($msg['count'] !== '')?$msg['count']:0)); ?>"<?php endif; ?>><?php echo lang("消息"); ?></a>
            <div class="header-sub-menu relative pointer" data-animation="menu-pop">
                <div class="block text-decoration-none h3 header-color count"></div>
            </div>
            <div class="header-sub-menu relative pointer" data-animation="menu-pop">
                <div class="block text-decoration-none h3 header-color count"></div>
            </div>
        </div>
    </div>
    <div class="flex-auto flex items-center justify-end z3 me2">
        <?php if(app('session')->get('isLogin') == true): ?>
        <div class="header-sub-menu relative profile-icon" data-animation="menu-pop">
            <div class="profile-header-image circle shadow border relative mx2 flex items-center justify-center circle overflow-hidden card-image-bg-color">
                <div class="profile-bg" data-cm-modal-url="" style="background-image:url('/public/upload/<?php echo htmlentities($u['main_pic']); ?>')"></div>
            </div>
        </div>


        <?php endif; ?>
        <div>
            <?php if(app('session')->get('isLogin') == true): ?>

            <a href="/index.php/index/a/logout" type="button" id="loginout"
               class="h3 rounded py1 px2 btn-color btn-bg border-none col-12 relative overflow-hidden shadow"
               tabindex="3" data-disable-on-click="true"><?php echo lang("退出"); ?>
            </a>
            <?php else: ?>
            <a href="/index.php/index/a/login"
               class="h3 rounded py1 px2 btn-color btn-bg border-none col-12 relative overflow-hidden shadow"
               tabindex="3" data-disable-on-click="true">登录
            </a>
            <?php endif; ?>
        </div>
    </div>
</div>




<div class="header flex items-center justify-between"></div>


<div class="absolute right-0 m1 h5 flex">
    <div class="me3">最后登陆时间: 昨天</div>
    148 / 1000
</div>
<div class="profile sm-col-9 lg-col-8 mx-auto flex">
    <div class="profile-image circle pointer shadow border me3 relative flex-none">
        <div class="overflow-hidden fit col-12 height-12 circle card-image-bg-color">

            <div class="profile-bg" data-cm-modal-URL="/zc/profile/showphotodisplaywidget?memberid=2260491"
                 style="background-image:url('https://cdn.chinalovecupid.com/memphoto/Photo1/big/2260491.jpg?impolicy=facegravity-fcrop-var&w=200&h=200')"></div>

        </div>

        <div class="icon-holder absolute">

        </div>
        <div class="border-box online circle absolute flex items-center justify-center border-white fill-grey">
            <svg class="col-12 height-12 tooltip">
                <use xlink:href="/assets/desktop/icons/icons.svg#icon-online"></use>
            </svg>

            <div class="tooltip-text tooltip-text-width-auto truncate tooltip-text-center h5 rounded p1 bg-black-alpha-85 white absolute max-width-1 no-select">
                最后登陆时间: 昨天
            </div>

        </div>
    </div>
    <div class="profile-details mt3 col-12">
        <div class="profile-details-name flex justify-between">
            <h2 class="m0 mt2 flex items-center color-dark-grey">
                Elva


            </h2>
        </div>

        <p class="m0">35 <span>&#8226;</span> 太原市, 山西, 中国 </p>
        <p class="mt1 mb0">
            女性 /
            单身 /
            会员号: 2260491
        </p>

        <p class="mt0 mb2">
            寻找 男性 29 - 45 寻找: 友谊, 婚姻对象
        </p>


        <div class="flex">


            <div class="flex flex-auto items-center justify-between">

                <div class="flex items-center mxn1 fill-white">
                    <div class="pointer circle icon-padding shadow relative bg-dark-grey"
                         data-profile="true" data-button="true"
                         data-animation="pop-fade-out"
                         data-showInterest="/zc/memberRelationship/showInterest/0D0585E6C0C047B4459D0A"
                    >

                        <svg class="icon-30 tooltip">
                            <use xlink:href="/assets/desktop/icons/icons.svg#icon-heart"></use>
                        </svg>

                        <div class="tooltip-text truncate tooltip-text-width-auto h5 rounded p1 bg-black-alpha-85 white absolute max-width-1 no-select">
                            发送秋波给Elva
                        </div>

                    </div>
                    <div class="pointer circle icon-padding mx1 shadow inactive relative bg-dark-grey"
                         data-chatMemberID="2260491">

                        <svg class="icon-30 tooltip">
                            <use xlink:href="/assets/desktop/icons/icons.svg#icon-messages"></use>
                        </svg>

                        <div class="tooltip-text truncate tooltip-text-width-auto h5 rounded p1 bg-black-alpha-85 white absolute max-width-1 no-select">
                            发送讯息给Elva
                        </div>

                    </div>
                    <div class="pointer circle relative me1 fill-action-highlight" >

                        <svg class="icon-50 tooltip">
                            <use xlink:href="/assets/desktop/icons/icons.svg#icon-star"></use>
                        </svg>

                        <div class="tooltip-text truncate tooltip-text-center tooltip-text-width-auto h5 rounded p1 bg-black-alpha-85 white absolute max-width-1 no-select">
                            将Elva加入最爱
                        </div>

                    </div>

                </div>

            </div>


        </div>
    </div>
</div>
<div class="overview sm-col-10 lg-col-9 max-width mx-auto mb3">
    <h3></h3>
    <div class="overview-details">

        <div class="row flex items-stretch">
            <div class="col-3 flex items-center justify-between p1">
                身高:
            </div>
            <div class="col-5 me3 p1 relative overview-details-bg ">

                <div class=" absolute top-0 right-0 bottom-0 left-0"></div>
                158 cm
            </div>


        </div>

        <div class="row flex items-stretch">
            <div class="col-3 flex items-center justify-between p1">
                体重:
            </div>
            <div class="col-5 me3 p1 relative overview-details-bg ">
                <div class=" absolute top-0 right-0 bottom-0 left-0"></div>
                45 kg
            </div>
        </div>

        <div class="row flex items-stretch">
            <div class="col-3 flex items-center justify-between p1">
                体型:
            </div>
            <div class="col-5 me3 p1 relative overview-details-bg ">

                <div class="nomatch absolute top-0 right-0 bottom-0 left-0" title="会员不符合您搜索条件"></div>
                娇小
            </div>
        </div>

        <div class="row flex items-stretch">
            <div class="col-3 flex items-center justify-between p1">
                国籍:
            </div>
            <div class="col-5 me3 p1 relative overview-details-bg ">

                <div class="match absolute top-0 right-0 bottom-0 left-0" title="会员符合您搜索条件"></div>
                中国
            </div>
        </div>

    </div>
</div>
</body>
</html>