<?php /*a:3:{s:93:"C:\Users\learn\Desktop\servers\nginx-1.15.8\chinaese6\application\index\view\index\index.html";i:1551607657;s:47:"../application/index/view/index/_commoncss.html";i:1551352303;s:42:"../application/index/view/index/_head.html";i:1551339764;}*/ ?>
<!DOCTYPE html>
<html dir="ltr" lang="zh-Hans" data-device="desktop">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title></title>
    <meta name="viewport"
          content="height=device-height, initial-scale=1, user-scalable=no, maximum-scale=1, shrink-to-fit=yes">
    <meta name="stm-result" content="ok"/>
    <meta name="keywords" content="<?php echo htmlentities((isset($keywords) && ($keywords !== '')?$keywords:'')); ?>"/>
    <link rel="shortcut icon" href="/favicon.ico"/>
<link rel="stylesheet" href="/assets/desktop/css/chinalovecupid-base.css?v=22">
<link href="/gcss/css1.css" rel="stylesheet">
<link href="/gcss/css2.css" rel="stylesheet">
<link href="/gcss/css3.css" rel="stylesheet">
<link href="/gcss/notosanstc.css" rel="stylesheet"/>
<link href="/gcss/notosansscsliced.css" rel="stylesheet"/>
<link href="/gcss/css_M+PLUS+1p.css" rel="stylesheet">
<link href="/gcss/css_Tajawal.css" rel="stylesheet">
<script src="/js/jquery-3.3.1.min.js"></script>
<script src="/js/tolang.js"></script>

</head>
<body>
<div class="header flex items-center justify-between">
    <div class="col-6 header-nav-min-width header-nav-max-width z0 mx2">
        <div class="flex items-center justify-between p0 m0 h3">
            <a href="/" class="flex" title="xxxx">
                <div class="z2 center col-12">www.chinalove1.com</div>
            </a>
            <a href="/" class="count" ><?php echo lang('首页'); ?></a>

            <a href="/index.php/index/mail/msglist" class="count" <?php if(app('session')->get('isLogin') == true): ?>data-badge="<?php echo htmlentities((isset($msg['count']) && ($msg['count'] !== '')?$msg['count']:0)); ?>"<?php endif; ?>><?php echo lang("消息"); ?></a>
            <div class="header-sub-menu relative pointer" data-animation="menu-pop">
                <div class="block text-decoration-none h3 header-color count"></div>
            </div>
            <div class="header-sub-menu relative pointer" data-animation="menu-pop">
                <div class="block text-decoration-none h3 header-color count"></div>
            </div>
        </div>
    </div>
    <div class="flex-auto flex items-center justify-end z3 me2">
        <?php if(app('session')->get('isLogin') == true): ?>
        <div class="header-sub-menu relative profile-icon" data-animation="menu-pop">
            <div class="profile-header-image circle shadow border relative mx2 flex items-center justify-center circle overflow-hidden card-image-bg-color">
                <div class="profile-bg" data-cm-modal-url="" style="background-image:url('/public/upload/<?php echo htmlentities($u['main_pic']); ?>')"></div>
            </div>
        </div>


        <?php endif; ?>
        <div>
            <?php if(app('session')->get('isLogin') == true): ?>

            <a href="/index.php/index/a/logout" type="button" id="loginout"
               class="h3 rounded py1 px2 btn-color btn-bg border-none col-12 relative overflow-hidden shadow"
               tabindex="3" data-disable-on-click="true"><?php echo lang("退出"); ?>
            </a>
            <?php else: ?>
            <a href="/index.php/index/a/login"
               class="h3 rounded py1 px2 btn-color btn-bg border-none col-12 relative overflow-hidden shadow"
               tabindex="3" data-disable-on-click="true">登录
            </a>
            <?php endif; ?>
        </div>
    </div>
</div>


<div class="header-strip height-auto px3 py2">
    <?php if(app('session')->get('isLogin') == true): ?>
    <div class="max-width flex items-center justify-between mx-auto">
        <div class="flex flex-wrap items-center flex-auto">
            <div class="mb1 me3 relative flex-none">
                <div class="profile-image-header circle shadow border">
                    <div class="flex items-center justify-center height-12 circle overflow-hidden card-image-bg-color">
                        <a class="col-12 height-12" href="/index/m/profile/<?php echo htmlentities($u['id']); ?>">
                            <div class="profile-bg"
                                 style="background-image:url('http://www.bytrip.com/<?php echo htmlentities($u['main_pic']); ?>')"></div>
                        </a>
                    </div>
                </div>
                <div class="icon-holder flex absolute">
                    <div class="icon-24 white flex items-center justify-center pointer bg-white fill-standard  border circle relative">

                        <svg class="icon-16 tooltip">
                            <use xmlns:xlink="http://www.w3.org/1999/xlink"
                                 xlink:href="/assets/desktop/icons/icons.svg#icon-profile"></use>
                        </svg>

                        <div class="tooltip-text truncate tooltip-text-width-auto h5 rounded p1 bg-black-alpha-85 white absolute max-width-1 no-select">
                            普通会员
                        </div>

                    </div>

                </div>
            </div>
            <div class="me2 col-6">
                <h1 class="m0 flex items-center"><?php echo htmlentities((isset($u['nickname']) && ($u['nickname'] !== '')?$u['nickname']:"")); ?>,<?php echo lang("您好"); ?></h1>

                <a class="next-step block mt1 p1 header-strip-color relative white rounded bg-search button overflow-hidden shadow"
                   href="/zc/profilemanagement/editprofilephotos">
                    下一步: 上传多张照片到相片区
                </a>
            </div>
        </div>
        <div class="header-info col-7 flex items-start justify-around">


            <a href="/zc/mail/showinbox">
                <div class="m2">
                    <div class="relative">
                        <div class="header-circles circle border relative mx-auto header-circles-highlight">

                            <svg>
                                <use xmlns:xlink="http://www.w3.org/1999/xlink"
                                     xlink:href="/assets/desktop/icons/icons.svg#icon-messages"></use>
                            </svg>

                        </div>

                        <div class="h3 count header-strip-color">2</div>

                    </div>
                    <h4 class="h4 mb0 center header-strip-color"><?php echo lang('新消息'); ?></h4>
                </div>
            </a>

            <a href="/zc/results/interestedme?searchtype=1">
                <div class="m2">
                    <div class="relative">
                        <div class="header-circles circle border relative mx-auto">

                            <svg>
                                <use xmlns:xlink="http://www.w3.org/1999/xlink"
                                     xlink:href="/assets/desktop/icons/icons.svg#icon-heart"></use>
                            </svg>

                        </div>

                        <div class="h3 count header-strip-color">0</div>

                    </div>
                    <h4 class="h4 mb0 center header-strip-color"><?php echo lang("新秋波"); ?></h4>
                </div>
            </a>

            <a href="/zc/results/viewedmyprofile?searchtype=1">
                <div class="m2">
                    <div class="relative">
                        <div class="header-circles circle border relative mx-auto header-circles-highlight">

                            <svg>
                                <use xmlns:xlink="http://www.w3.org/1999/xlink"
                                     xlink:href="/assets/desktop/icons/icons.svg#icon-eye"></use>
                            </svg>

                        </div>

                        <div class="h3 count header-strip-color">1</div>

                    </div>
                    <h4 class="h4 mb0 center header-strip-color"><?php echo lang("新浏览"); ?></h4>
                </div>
            </a>

            <a href="/zc/results/favoritedme?searchtype=1">
                <div class="m2">
                    <div class="relative">
                        <div class="header-circles circle border relative mx-auto">

                            <svg>
                                <use xmlns:xlink="http://www.w3.org/1999/xlink"
                                     xlink:href="/assets/desktop/icons/icons.svg#icon-star"></use>
                            </svg>

                        </div>

                        <div class="h3 count header-strip-color">0</div>

                    </div>
                    <h4 class="h4 mb0 center header-strip-color"><?php echo lang("新的最爱"); ?></h4>
                </div>
            </a>

        </div>
    </div>
    <?php endif; ?>
    <form action="/zc/results/search?searchtype=1" method="post" novalidate="">
        <div class="search mt2 p2 mx-auto shadow rounded flex flex-wrap items-center justify-between max-width">
            <div class="border-bottom m1 col-2">
                <label for="form-quick-search-seeking"><?php echo lang('寻找'); ?></label>


                <select name="gender_w" id="form-quick-search-seeking" class="col-12">

                    <option value="-1">不限</option>

                    <option value="253">男性</option>

                    <option value="254" selected="">女性</option>

                </select>

            </div>

            <div class="border-bottom search-age m1">
                <label for="form-quick-search-age-min">年龄</label>
                <div class="flex items-center">


                    <select name="age_min" id="form-quick-search-age-min" class="col-12">

                        <option value="-1">-</option>

                        <option value="18">18</option>

                        <option value="19">19</option>

                        <option value="20">20</option>

                        <option value="21">21</option>

                        <option value="22" selected="">22</option>

                        <option value="23">23</option>

                        <option value="24">24</option>

                        <option value="25">25</option>

                        <option value="26">26</option>

                        <option value="27">27</option>

                        <option value="28">28</option>

                        <option value="29">29</option>

                        <option value="30">30</option>

                        <option value="31">31</option>

                        <option value="32">32</option>

                        <option value="33">33</option>

                        <option value="34">34</option>

                        <option value="35">35</option>

                        <option value="36">36</option>

                        <option value="37">37</option>

                        <option value="38">38</option>

                        <option value="39">39</option>

                        <option value="40">40</option>

                        <option value="41">41</option>

                        <option value="42">42</option>

                        <option value="43">43</option>

                        <option value="44">44</option>

                        <option value="45">45</option>

                        <option value="46">46</option>

                        <option value="47">47</option>

                        <option value="48">48</option>

                        <option value="49">49</option>

                        <option value="50">50</option>

                        <option value="51">51</option>

                        <option value="52">52</option>

                        <option value="53">53</option>

                        <option value="54">54</option>

                        <option value="55">55</option>

                        <option value="56">56</option>

                        <option value="57">57</option>

                        <option value="58">58</option>

                        <option value="59">59</option>

                        <option value="60">60</option>

                        <option value="61">61</option>

                        <option value="62">62</option>

                        <option value="63">63</option>

                        <option value="64">64</option>

                        <option value="65">65</option>

                        <option value="66">66</option>

                        <option value="67">67</option>

                        <option value="68">68</option>

                        <option value="69">69</option>

                        <option value="70">70</option>

                        <option value="71">71</option>

                        <option value="72">72</option>

                        <option value="73">73</option>

                        <option value="74">74</option>

                        <option value="75">75</option>

                        <option value="76">76</option>

                        <option value="77">77</option>

                        <option value="78">78</option>

                        <option value="79">79</option>

                        <option value="80">80</option>

                        <option value="81">81</option>

                        <option value="82">82</option>

                        <option value="83">83</option>

                        <option value="84">84</option>

                        <option value="85">85</option>

                        <option value="86">86</option>

                        <option value="87">87</option>

                        <option value="88">88</option>

                        <option value="89">89</option>

                        <option value="90">90</option>

                        <option value="91">91</option>

                        <option value="92">92</option>

                        <option value="93">93</option>

                        <option value="94">94</option>

                        <option value="95">95</option>

                        <option value="96">96</option>

                        <option value="97">97</option>

                        <option value="98">98</option>

                        <option value="99">99</option>

                    </select>


                    <select name="age_max" id="form-quick-search-age-max" class="col-12">

                        <option value="-1">-</option>

                        <option value="18">18</option>

                        <option value="19">19</option>

                        <option value="20">20</option>

                        <option value="21">21</option>

                        <option value="22">22</option>

                        <option value="23">23</option>

                        <option value="24">24</option>

                        <option value="25">25</option>

                        <option value="26">26</option>

                        <option value="27">27</option>

                        <option value="28">28</option>

                        <option value="29">29</option>

                        <option value="30">30</option>

                        <option value="31">31</option>

                        <option value="32">32</option>

                        <option value="33">33</option>

                        <option value="34">34</option>

                        <option value="35">35</option>

                        <option value="36">36</option>

                        <option value="37">37</option>

                        <option value="38" selected="">38</option>

                        <option value="39">39</option>

                        <option value="40">40</option>

                        <option value="41">41</option>

                        <option value="42">42</option>

                        <option value="43">43</option>

                        <option value="44">44</option>

                        <option value="45">45</option>

                        <option value="46">46</option>

                        <option value="47">47</option>

                        <option value="48">48</option>

                        <option value="49">49</option>

                        <option value="50">50</option>

                        <option value="51">51</option>

                        <option value="52">52</option>

                        <option value="53">53</option>

                        <option value="54">54</option>

                        <option value="55">55</option>

                        <option value="56">56</option>

                        <option value="57">57</option>

                        <option value="58">58</option>

                        <option value="59">59</option>

                        <option value="60">60</option>

                        <option value="61">61</option>

                        <option value="62">62</option>

                        <option value="63">63</option>

                        <option value="64">64</option>

                        <option value="65">65</option>

                        <option value="66">66</option>

                        <option value="67">67</option>

                        <option value="68">68</option>

                        <option value="69">69</option>

                        <option value="70">70</option>

                        <option value="71">71</option>

                        <option value="72">72</option>

                        <option value="73">73</option>

                        <option value="74">74</option>

                        <option value="75">75</option>

                        <option value="76">76</option>

                        <option value="77">77</option>

                        <option value="78">78</option>

                        <option value="79">79</option>

                        <option value="80">80</option>

                        <option value="81">81</option>

                        <option value="82">82</option>

                        <option value="83">83</option>

                        <option value="84">84</option>

                        <option value="85">85</option>

                        <option value="86">86</option>

                        <option value="87">87</option>

                        <option value="88">88</option>

                        <option value="89">89</option>

                        <option value="90">90</option>

                        <option value="91">91</option>

                        <option value="92">92</option>

                        <option value="93">93</option>

                        <option value="94">94</option>

                        <option value="95">95</option>

                        <option value="96">96</option>

                        <option value="97">97</option>

                        <option value="98">98</option>

                        <option value="99">99</option>

                    </select>


                </div>
            </div>

            <div class="border-bottom m1 col-2">
                <label for="form-quick-search-country">国家</label>


                <select name="countryLive" id="form-quick-search-country" class="col-12"
                        data-dependentselect="stateLive">

                    <option value="-1">任何国家</option>

                    <optgroup label="热门搜索国家">

                        <option value="42">中国</option>

                    </optgroup>

                    <optgroup label="所有国家">

                        <option value="7">阿尔巴尼亚</option>

                        <option value="5">阿尔及尼亚</option>

                        <option value="4">阿富汗</option>

                        <option value="12">阿根廷</option>

                        <option value="3">阿拉伯聯合大公國</option>

                        <option value="1">阿盧巴</option>

                        <option value="147">阿曼</option>

                        <option value="6">阿塞拜疆</option>

                        <option value="61">埃及</option>

                        <option value="67">埃塞俄比亚</option>

                        <option value="62">爱尔兰</option>

                        <option value="64">爱沙尼亚</option>

                        <option value="9">安道尔</option>

                        <option value="10">安哥拉</option>

                        <option value="15">安圭拉岛</option>

                        <option value="2">安提瓜及巴不达</option>

                        <option value="14">奥地利</option>

                        <option value="13">澳大利亚</option>

                        <option value="134">澳门(中国)</option>

                        <option value="18">巴巴多斯</option>

                        <option value="173">巴布亚新几内亚</option>

                        <option value="22">巴哈马</option>

                        <option value="169">巴基斯坦</option>

                        <option value="166">巴拉圭</option>

                        <option value="93">巴勒斯坦</option>

                        <option value="17">巴林</option>

                        <option value="171">巴拿马</option>

                        <option value="30">巴西</option>

                        <option value="28">白俄罗斯</option>

                        <option value="20">百慕达</option>

                        <option value="32">保加利亚</option>

                        <option value="116">北朝鲜</option>

                        <option value="49">北马里亚纳群岛</option>

                        <option value="27">贝南</option>

                        <option value="21">比利时</option>

                        <option value="100">冰岛</option>

                        <option value="181">波多黎各</option>

                        <option value="170">波兰</option>

                        <option value="19">波扎那</option>

                        <option value="26">玻利维亚</option>

                        <option value="25">玻斯尼亚</option>

                        <option value="224">伯克尼</option>

                        <option value="24">伯利兹</option>

                        <option value="174">帛琉</option>

                        <option value="31">不丹</option>

                        <option value="35">布隆迪</option>

                        <option value="33">布为特岛</option>

                        <option value="63">赤道及内亚</option>

                        <option value="56">丹麦</option>

                        <option value="86">德国</option>

                        <option value="213">东帝汶</option>

                        <option value="210">多哥</option>

                        <option value="58">多米尼克</option>

                        <option value="59">多明尼加共和国</option>

                        <option value="182">俄罗斯</option>

                        <option value="60">厄瓜多尔</option>

                        <option value="65">厄立特里亚</option>

                        <option value="74">伐茹岛</option>

                        <option value="76">法国</option>

                        <option value="75">法属波利尼西亚</option>

                        <option value="92">法属圭亚那</option>

                        <option value="69">法属圭亚那</option>

                        <option value="77">法属南极领地</option>

                        <option value="232">梵蒂冈城</option>

                        <option value="180">菲律宾</option>

                        <option value="71">斐济</option>

                        <option value="70">芬兰</option>

                        <option value="53">佛得角</option>

                        <option value="72">福克兰群岛</option>

                        <option value="78">甘比亚</option>

                        <option value="40">刚果</option>

                        <option value="41">刚果</option>

                        <option value="48">哥仑比亚</option>

                        <option value="50">哥斯達黎亞</option>

                        <option value="84">格恩西</option>

                        <option value="85">格陵兰岛</option>

                        <option value="83">格瑞纳达</option>

                        <option value="52">古巴</option>

                        <option value="87">瓜德罗普岛</option>

                        <option value="88">关岛</option>

                        <option value="121">哈萨克</option>

                        <option value="94">海地</option>

                        <option value="118">韩国</option>

                        <option value="96">河地</option>

                        <option value="158">荷兰</option>

                        <option value="163">荷属安替列斯群岛</option>

                        <option value="246">黑山</option>

                        <option value="97">洪都拉斯</option>

                        <option value="57">吉布地</option>

                        <option value="115">吉尔吉斯</option>

                        <option value="91">几内亚</option>

                        <option value="175">几内亚比绍共和国</option>

                        <option value="36">加拿大</option>

                        <option value="81">加纳</option>

                        <option value="79">加彭</option>

                        <option value="37">柬埔寨</option>

                        <option value="68">捷克</option>

                        <option value="46">喀买隆</option>

                        <option value="176">卡达</option>

                        <option value="44">卡门群岛</option>

                        <option value="54">科克群岛</option>

                        <option value="47">科斯罗</option>

                        <option value="108">科特迪瓦</option>

                        <option value="120">科威特</option>

                        <option value="45">可可斯群岛</option>

                        <option value="117">克里巴提</option>

                        <option value="98">克罗埃西亚</option>

                        <option value="114">肯亚</option>

                        <option value="244">库拉索</option>

                        <option value="124">拉特威尼亚</option>

                        <option value="126">赖比瑞亚</option>

                        <option value="129">赖索托</option>

                        <option value="123">黎巴嫩</option>

                        <option value="125">立陶宛</option>

                        <option value="131">利比亚</option>

                        <option value="122">寮国</option>

                        <option value="128">列支敦士登</option>

                        <option value="177">留尼旺岛</option>

                        <option value="130">卢森堡</option>

                        <option value="183">卢旺达</option>

                        <option value="179">罗马尼亚</option>

                        <option value="132">马达加斯加</option>

                        <option value="135">马多瓦</option>

                        <option value="148">马尔代夫</option>

                        <option value="146">马耳他</option>

                        <option value="139">马拉维</option>

                        <option value="150">马来西亚</option>

                        <option value="141">马里</option>

                        <option value="140">马其顿</option>

                        <option value="178">马绍尔群岛</option>

                        <option value="133">马提尼克</option>

                        <option value="145">马提尼亚</option>

                        <option value="136">马幼提</option>

                        <option value="223">美国</option>

                        <option value="221">美属边疆群岛</option>

                        <option value="231">美属佛吉尼亚岛</option>

                        <option value="11">美属萨摩亚</option>

                        <option value="137">蒙古</option>

                        <option value="138">蒙色提</option>

                        <option value="23">孟加拉</option>

                        <option value="168">秘鲁</option>

                        <option value="73">密克罗西尼亚</option>

                        <option value="242">缅甸</option>

                        <option value="144">模里西斯</option>

                        <option value="143">摩洛哥</option>

                        <option value="142">摩纳哥</option>

                        <option value="151">莫桑比克</option>

                        <option value="149">墨西哥</option>

                        <option value="233">纳米比亚</option>

                        <option value="188">南非</option>

                        <option value="16">南极洲</option>

                        <option value="201">南乔治亚群岛</option>

                        <option value="161">瑙鲁</option>

                        <option value="160">尼泊尔</option>

                        <option value="164">尼加拉瓜</option>

                        <option value="155">尼日尔</option>

                        <option value="157">尼日利亚</option>

                        <option value="153">纽邬岛</option>

                        <option value="159">挪威</option>

                        <option value="154">诺福克岛</option>

                        <option value="167">皮特卡岛</option>

                        <option value="172">葡萄牙</option>

                        <option value="80">乔治亚</option>

                        <option value="110">日本</option>

                        <option value="200">瑞典</option>

                        <option value="203">瑞士</option>

                        <option value="66">萨尔瓦多</option>

                        <option value="236">萨摩亚</option>

                        <option value="238">塞尔维亚</option>

                        <option value="192">塞拉利昂</option>

                        <option value="189">塞内加尔</option>

                        <option value="55">塞普路斯</option>

                        <option value="187">塞舌尔群岛</option>

                        <option value="184">沙特阿拉伯</option>

                        <option value="119">圣诞岛</option>

                        <option value="211">圣多美岛和普林西比岛</option>

                        <option value="190">圣海伦</option>

                        <option value="186">圣卡特</option>

                        <option value="197">圣露西亚</option>

                        <option value="193">圣马</option>

                        <option value="245">圣马丁岛</option>

                        <option value="185">圣皮埃尔</option>

                        <option value="227">圣文森及格瑞那丁</option>

                        <option value="199">史巴答</option>

                        <option value="39">斯里兰卡</option>

                        <option value="127">斯洛伐克</option>

                        <option value="191">斯洛文尼亚</option>

                        <option value="237">斯威士兰</option>

                        <option value="198">苏丹</option>

                        <option value="243">苏丹南部</option>

                        <option value="162">苏利南</option>

                        <option value="29">所罗门岛</option>

                        <option value="195">索马里</option>

                        <option value="206">塔吉克</option>

                        <option value="218">塔桑尼亚</option>

                        <option value="216">台湾(中国)</option>

                        <option value="205">泰国</option>

                        <option value="209">汤加</option>

                        <option value="204">特立尼达和多巴哥</option>

                        <option value="212">突尼斯</option>

                        <option value="214">土耳其</option>

                        <option value="217">土库曼</option>

                        <option value="207">土库斯和凯科斯群岛</option>

                        <option value="215">土瓦魯</option>

                        <option value="208">托克勞群島</option>

                        <option value="156">万那杜</option>

                        <option value="90">危地马拉</option>

                        <option value="228">委内瑞拉</option>

                        <option value="34">文莱</option>

                        <option value="234">沃利斯和富图纳群岛</option>

                        <option value="219">乌干达</option>

                        <option value="222">乌克兰</option>

                        <option value="225">乌拉圭</option>

                        <option value="226">乌兹别克</option>

                        <option value="196">西班牙</option>

                        <option value="235">西撒哈拉</option>

                        <option value="89">希腊</option>

                        <option value="95">香港(中国)</option>

                        <option value="241">辛巴威</option>

                        <option value="194">新加坡</option>

                        <option value="152">新克罗第尼亚</option>

                        <option value="165">新西兰</option>

                        <option value="99">匈牙利</option>

                        <option value="202">叙利亚</option>

                        <option value="112">牙买加</option>

                        <option value="8">亚美尼亚</option>

                        <option value="239">也门</option>

                        <option value="109">伊拉克</option>

                        <option value="105">伊朗</option>

                        <option value="106">以色列</option>

                        <option value="107">意大利</option>

                        <option value="103">印度</option>

                        <option value="101">印度尼西亚</option>

                        <option value="220">英国</option>

                        <option value="104">英国印度海领地</option>

                        <option value="102">英属地曼岛</option>

                        <option value="229">英属佛吉尼亚岛</option>

                        <option value="113">约旦</option>

                        <option value="230">越南</option>

                        <option value="240">赞比亚</option>

                        <option value="111">泽西岛</option>

                        <option value="38">乍得</option>

                        <option value="82">直布罗陀</option>

                        <option value="43">智利</option>

                        <option value="51">中非共和国</option>

                        <option value="42">中国</option>

                    </optgroup>

                </select>

            </div>

            <div class="border-bottom m1 col-2">
                <label for="form-quick-search-state">省/县</label>


                <select name="stateLive" id="form-quick-search-state" class="col-12" data-dependentselect="cityLive"
                        formaction="/zc/widget/loadstates?countryid="
                        data-datamap="{&quot;group&quot;:&quot;STATEVALUE&quot;,&quot;text&quot;:&quot;TRANSLATION&quot;,&quot;value&quot;:&quot;ATTRIBUTEID&quot;}">

                    <option value="-1">任何州</option>

                </select>

            </div>

            <div class="border-bottom m1 col-2">
                <label for="form-quick-search-city">市</label>


                <select name="cityLive" id="form-quick-search-city" class="col-12"
                        formaction="/zc/widget/loadcities?stateid="
                        data-datamap="{&quot;group&quot;:&quot;STATEVALUE&quot;,&quot;text&quot;:&quot;TRANSLATION&quot;,&quot;value&quot;:&quot;ATTRIBUTEID&quot;}">

                    <option value="-1">任何城市</option>

                </select>

            </div>

            <div class="border-bottom m1">
                <label for="form-quick-search-livingWithinRadius">之内</label>
                <div class="flex items-center">

                    <select name="livingWithinRadius" id="form-quick-search-livingWithinRadius" class="col-12">
                        <option value="-1">-</option>

                        <option value="50">50</option>

                        <option value="100">100</option>

                        <option value="250">250</option>

                        <option value="500">500</option>

                    </select>
                    <p class="p0 m0 weight-400">kms</p>

                    <input type="hidden" name="distanceUnit" value="kms">

                </div>
            </div>

            <input type="hidden" value="1" name="hasPhoto">
            <input type="hidden" value="advanced" name="resulttype">

            <button class="h4 py1 px2 rounded shadow border-none upper-case pointer">搜索</button>
        </div>
    </form>
</div>
<div class="max-width mx-auto mt4 px2">
    <div class="flex items-center justify-between mt2 max-width mx-auto"></div>
</div>
<div class="flex flex-wrap justify-center max-width mx-auto" data-reflow="true">
    <?php if(is_array($members) || $members instanceof \think\Collection || $members instanceof \think\Paginator): $i = 0; $__LIST__ = $members;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$m): $mod = ($i % 2 );++$i;?>
    <div class="card-s card m1 flex flex-wrap overflow-hidden bg-white shadow relative">
        <a id="<?php echo htmlentities($m['id']); ?>" class="absolute top-minus-100"></a>

        <a class="flex items-center col-12 justify-center std relative"
           href="/index.php/index/m/profile/<?php echo htmlentities($m['id']); ?>.html">
            <div class="profile-bg" data-cm-modal-URL=""
                 style="background-image:url('http://www.bytrip.com/<?php echo htmlentities($m['main_pic']); ?>')"></div>
            <div class="border-box z2 flex items-center justify-center standard-online online circle border-white">
                <svg class="col-12 height-12" data-tooltip="ttOn">
                    <use xlink:href="/assets/desktop/icons/icons.svg#icon-online"></use>
                </svg>
                <div hidden><?php echo lang("我在线"); ?></div>
            </div>
        </a>

        <div class="sdh col-12 relative flex flex-column">

            <div class="flex items-center mx2 mt2">
                <a href="/index.php/index/m/profile/<?php echo htmlentities($m['id']); ?>.html"
                   class="h3 color-dark-grey m0 truncate max-width-85"><?php echo htmlentities($m['nickname']); ?></a>
                <div class="icon-membership ms1 fill-standard relative">
                    <svg class="ms1 fill-standard relative" data-tooltip="ttCn">
                        <use xlink:href="/assets/desktop/icons/icons.svg#icon-profile"></use>
                    </svg>
                    <div hidden><?php echo lang("普通会员"); ?></div>
                </div>
            </div>

            <div class="mx2 h5">
               <?php echo htmlentities($m['age']); ?> <span>&#8226;</span>  <?php echo htmlentities($m['address']); ?>, <?php echo htmlentities((isset($m['country']) && ($m['country'] !== '')?$m['country']:"")); ?>
            </div>



            <div class="flex flex-auto items-end justify-between mx2 my2">
                <div class="flex items-center">
                    <div data-button="true"

                         class="pointer me3 relative fill-action-unhighlight"
                         data-animation="pop-fade-out"
                         data-showInterest="/zc/memberrelationship/showInterest/0E008BE0C7C146B4459D0A"
                         title="发送秋波给Yu"

                    >

                        <svg class="icon-30">
                            <use xlink:href="/assets/desktop/icons/icons.svg#icon-heart"></use>
                        </svg>
                    </div>
                    <div class="pointer me3 fill-action-unhighlight relative"
                         data-button="true"
                         data-animate-reset="single-heartbeat"
                         data-chatMemberID="1786380"
                         title="发送讯息给Yu">

                        <svg class="icon-30">
                            <use xlink:href="/assets/desktop/icons/icons.svg#icon-messages"></use>
                        </svg>
                    </div>

                </div>
                <div class="fill-action-unhighlight relative" data-button="true" data-animate-reset="heartbeat">
                    <div class="pointer no-highlight flex items-center"
                         data-cm-modal-URL="/zc/profile/showphotodisplaywidget?memberid=1786380"
                         title="照片">

                        <svg class="icon-30">
                            <use xlink:href="/assets/desktop/icons/icons.svg#icon-camera"></use>
                        </svg>
                        <div class="ms2 h5">5</div>
                    </div>
                </div>
            </div>

        </div>
    </div>


    <?php endforeach; endif; else: echo "" ;endif; ?>





    <a href="/?pno=<?php echo htmlentities($nextPno); ?>" class="block col m1 card-s">
        <div class="col-12 height-12">
            <div class="card height-12 flex items-center justify-center next-button rounded border">
                <div class="flex items-center">
                    <div class="center">
                        <h2 class="h2 m0 caps">下一页</h2>
                    </div>
                    <div class="fill-standard">
                        <svg class="icon-next-button">
                            <use xlink:href="/assets/desktop/icons/icons.svg#icon-menuright"></use>
                        </svg>
                    </div>
                </div>
            </div>
        </div>
    </a>
</div>

<div class="max-width mt2 px2 mx-auto">
    <div class="flex justify-between items-center caps">
        <div class="flex">

            <div class="flex items-center me2 opacity-6">
                <div class="fill-standard me1">
                    <svg class="icon-first">
                        <use xlink:href="/assets/desktop/icons/icons.svg#icon-first"></use>
                    </svg>
                </div>
                <a href="/?pno=1">第一页</a>
            </div>

            <div class="flex items-center opacity-6">
                <div class="fill-standard me1">
                    <svg class="icon-prev">
                        <use xlink:href="/assets/desktop/icons/icons.svg#icon-menuleft"></use>
                    </svg>
                </div>
                上一页
            </div>

        </div>

        <div class="flex">

            <a href="/?pno=<?php echo htmlentities($nextPno); ?>">
                <div class="flex items-center">
                    下一页
                    <div class="fill-standard mx1">
                        <svg class="icon-next">
                            <use xlink:href="/assets/desktop/icons/icons.svg#icon-menuright"></use>
                        </svg>
                    </div>
                </div>
            </a>

            <a href="showMenu?pageno=29">
                <div class="flex items-center ms2">
                    最末页
                    <div class="fill-standard ms1">
                        <svg class="icon-last">
                            <use xlink:href="/assets/desktop/icons/icons.svg#icon-last"></use>
                        </svg>
                    </div>
                </div>
            </a>

        </div>
    </div>
</div>

<!--Body end-->
</body>

</html>