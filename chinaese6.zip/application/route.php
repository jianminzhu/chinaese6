<?php
use think\Route;                        //引入Route
Route::rule('test','index/index/helo');