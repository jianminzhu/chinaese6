<?php


$py = new Pinyin();

echo $py->pinyin("中国");